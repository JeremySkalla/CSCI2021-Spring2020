int run_plugin(){
  return 5;
}

int global = 2;
